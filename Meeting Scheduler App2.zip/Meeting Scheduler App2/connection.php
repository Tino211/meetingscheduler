<?php 
$con = mysqli_connect('localhost', 'root', '', 'userforms','3306');
?>