<?php
$conn = mysqli_connect("localhost", "root", "", "userforms");
